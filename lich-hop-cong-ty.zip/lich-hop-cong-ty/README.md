# Lịch họp công ty

Bài thực hành HTML về gộp ô trong bảng bằng `rowspan` và `colspan`.

## Chạy
Mở `index.html` bằng trình duyệt web.
